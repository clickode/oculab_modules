===========================

Theme Clarico - Odoo Business Theme & Odoo eCommerce Theme

================================

Fully Responsive Odoo Theme suitable for eCommerce Businesses like Furniture, Fashion, Beauty, Construction, Sports, Construction/Real Estate, Electronics, Fashion, Furniture, Beauty, Hotel, Medical, Services, Corporate, Jewellary, Art/Photography, Food/Drink, Home/Garden, Toys/Games, Animals/Pets, Education/Books, Cars/MotorCycles, Travel/Holidays, Restaurent, Entertainment, Holidays, Gifts & Flowers etc..


Features

========  

- 6 header styles
- 3 footer styles
- 10 button styles
- Dynamic Product Slider(4 Single slider styles + 4 Multi slider styles)
- nth level Dynamic Mega Menu
- 6 mega menu styles
- Category Carousel
- Blog Carousel
- Quick View
- Breadcrumb in shop page
- Category wise landing page
- 10 predefined fonts
- 50+ snippets
- Sale label in shop
- Accesories and Alternative Product Sliders
- Employee and customer sliders
- Social sharing in product page
- Configurable Menu styles
- Customizable offer banner in shop, wishlist and cart page
- Dynamic Progress bar (Expertise)
- Global Header Search




Similar Apps
==========

Mega Menu in Theme
Product Slider
Odoo Theme
Odoo Website
Best Odoo eCommerce Theme
Best Odoo Theme
Odoo eCommerce
Top Odoo Theme
Odoo Website Theme
